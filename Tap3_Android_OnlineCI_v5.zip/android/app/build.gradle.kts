plugins{ id("com.android.application") }
android{
  namespace="com.tap3game.android"
  compileSdk=34
  defaultConfig{
    applicationId="com.tap3game.android"
    minSdk=23
    targetSdk=34
    versionCode=1
    versionName="1.0.0"
  }
  signingConfigs {
    create("release") {
      // Will be set by CI after keystore is created/restored
      val ksPath = System.getenv("KEYSTORE_PATH") ?: ""
      val ksPass = System.getenv("KEYSTORE_PASSWORD") ?: ""
      val keyAlias = System.getenv("KEY_ALIAS") ?: ""
      val keyPass = System.getenv("KEY_PASSWORD") ?: ""
      if (ksPath.isNotEmpty()) {
        storeFile = file(ksPath)
        storePassword = ksPass
        this.keyAlias = keyAlias
        keyPassword = keyPass
      }
    }
  }
  buildTypes{
    release{
      isMinifyEnabled=false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug{ isDebuggable=true }
  }
}
dependencies{
  implementation("androidx.appcompat:appcompat:1.7.0")
}
