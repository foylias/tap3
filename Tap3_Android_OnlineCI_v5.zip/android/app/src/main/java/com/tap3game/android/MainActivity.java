package com.tap3game.android;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebSettings;
public class MainActivity extends AppCompatActivity{
  @Override protected void onCreate(Bundle savedInstanceState){
    super.onCreate(savedInstanceState);
    WebView w=new WebView(this);
    WebSettings s=w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    w.loadUrl("file:///android_asset/public/index.html");
    setContentView(w);
  }
}
